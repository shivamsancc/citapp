<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Include this in your blade layout -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js?v=2"></script>

</head>
<body>
    @include('sweet::alert')
</body>
</html>

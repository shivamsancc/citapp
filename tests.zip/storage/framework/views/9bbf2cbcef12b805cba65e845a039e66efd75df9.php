<?php $__env->startSection('content'); ?>
<div class="container-fluid m-0 p-0">
    <div class="row m-0 p-0">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="container-fluid m-0 p-0">
                        <div class="row m-0 p-0">
                            <div class="col-6">
                              <div class="container ca-frontboxsingle rounded">
                                  <h2>Upload Cerificate:</h2>
                                  <div class="panel panel-default">
                                    <div class="panel-body">Please Select a CSV or .xlsx</div><br>
                                    <form method="post" role="form" action="<?php echo e(route('importcerificate')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                                      <div class="form-row align-items-center">
                                        <div class="col-auto">
                                          <label class="sr-only" for="inlineFormInput">Name</label>
                                          <input type="file" name="file" class="form-control mb-2" id="inlineFormInput" placeholder="ENTER YOUR SERIAL NUMBER">
                                        </div>
                                        <div class="col-auto">
                                          <button type="submit" class="btn btn-primary mb-2">Submit</button>
                                        </div>
                                      </div>
                                    </form>
                                  </div>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="container ca-frontboxsingle rounded">
                                  <h2>Upload Admit Card:</h2>
                                  <div class="panel panel-default">
                                    <div class="panel-body">Please Select a CSV or .xlsx</div><br>
                                    <form method="post" role="form" action="<?php echo e(route('importadmitcard')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                                      <div class="form-row align-items-center">
                                        <div class="col-auto">
                                          <label class="sr-only" for="inlineFormInput">Name</label>
                                          <input type="file" name="file" class="form-control mb-2" id="inlineFormInput" placeholder="ENTER YOUR REGISTRATION NUMBER">
                                        </div>
                                        <div class="col-auto">
                                          <button type="submit" class="btn btn-primary mb-2">Submit</button>
                                        </div>
                                      </div>
                                    </form>
                                  </div>
                              </div>
                            </div>
                        </div>
                        <div class="row m-0 p-0" style=" margin-top:50px !important;">
                            <div class="col-6">
                              <div class="container ca-frontboxsingle rounded">
                                  <h2>Upload Result:</h2>
                                  <div class="panel panel-default">
                                    <div class="panel-body">Please Select a CSV or .xlsx</div><br>
                                    <form method="post" role="form" action="<?php echo e(route('importaresult')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                                      <div class="form-row align-items-center">
                                        <div class="col-auto">
                                          <label class="sr-only" for="inlineFormInput">Name</label>
                                          <input type="file" name="file" class="form-control mb-2" id="inlineFormInput" placeholder="ENTER YOUR Roll NUMBER">
                                        </div>
                                        <div class="col-auto">
                                          <button type="submit" class="btn btn-primary mb-2">Submit</button>
                                        </div>
                                      </div>
                                    </form>
                                  </div>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="container ca-frontboxsingle rounded">
                                  <h2>Upload Addmission Conformation:</h2>
                                  <div class="panel panel-default">
                                    <div class="panel-body">Please Select a CSV or .xlsx</div><br>
                                    <form method="post" role="form" action=""><?php echo csrf_field(); ?>
                                      <div class="form-row align-items-center">
                                        <div class="col-auto">
                                          <label class="sr-only" for="inlineFormInput">Name</label>
                                          <input type="file" name="file" class="form-control mb-2" id="inlineFormInput" placeholder="ENTER YOUR REGISTRATION NUMBER">
                                        </div>
                                        <div class="col-auto">
                                          <button type="submit" class="btn btn-primary mb-2">Submit</button>
                                        </div>
                                      </div>
                                    </form>
                                  </div>
                              </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\citapp\resources\views/home.blade.php ENDPATH**/ ?>
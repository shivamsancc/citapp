<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Include this in your blade layout -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js?v=2"></script>

</head>
<body>
    <?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\citapp\resources\views/layouts/notification.blade.php ENDPATH**/ ?>